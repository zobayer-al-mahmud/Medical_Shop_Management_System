#### Medical_Shop_Management_System
### Badhon Kumar Biswas   and his team member developed this project.
## Dept. of CSE at AIUB
